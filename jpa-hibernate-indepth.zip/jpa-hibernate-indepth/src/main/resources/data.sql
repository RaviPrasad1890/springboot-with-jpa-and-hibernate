INSERT into course (id,name,created_date, last_updated_date)
values(101,'Springboot',sysdate(), sysdate());
INSERT into course (id,name,created_date, last_updated_date)
values(102,'Spring jpa',sysdate(),sysdate());
INSERT into course (id,name,created_date, last_updated_date)
values(103,'Spring rest',sysdate(),sysdate());
INSERT into course (id,name,created_date, last_updated_date)
values(104,'Spring microservices',sysdate(),sysdate());
