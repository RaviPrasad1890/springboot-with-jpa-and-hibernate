package com.ravi.jpa.hibernate.manytomany.repository;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ravi.jpa.hibernate.manytomany.entity.Course;
import com.ravi.jpa.hibernate.manytomany.entity.Passport;
import com.ravi.jpa.hibernate.manytomany.entity.Student;





@Repository
@Transactional
public class StudentRepository {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	EntityManager em;

	public Student findById(Long id) {
		return em.find(Student.class, id);
	}

	public Student save(Student student) {

		if (student.getId() == null) {
			em.persist(student);
		} else {
			em.merge(student);
		}

		return student;
	}

	public void deleteById(Long id) {
		Student student = findById(id);
		em.remove(student);
	}

	public void saveStudentWithPassport() {
		Passport passport = new Passport("Z123456");
		em.persist(passport);

		Student student = new Student("Mike");

		student.setPassport(passport);
		em.persist(student);	
	}
	
	public void someOperationToUnderstandPersistenceContext() {
		//Database Operation 1 - Retrieve student
		Student student = em.find(Student.class, 20001L);
		//Persistence Context (student):- now student is in persistence state
				
		//Database Operation 2 - Retrieve passport
		Passport passport = student.getPassport();
		//Persistence Context (student, passport):-now student and passport is in persistence state

		//Database Operation 3 - update passport
		passport.setNumber("E123457");
		//Persistence Context (student, passport++)
		
		//Database Operation 4 - update student
		student.setName("Ranga - updated");
		//Persistence Context (student++ , passport++)
	}
	
	public void retreiveStudentAndCourse(long studentId) {
		Student student=em.find(Student.class,studentId);
		/*
		 * QUERY GENERATED:
		 *     select
        student0_.id as id1_3_0_,
        student0_.name as name2_3_0_,
        student0_.passport_id as passport3_3_0_ 
    from
        student student0_ 
    where
        student0_.id=?
        
        Note: By default ManyToMany is lazy fetch
		 */
		logger.info("Student :"+student);
		logger.info("Course :"+student.getCourses());
		/*
		 * select
        courses0_.student_id as student_1_4_0_,
        courses0_.course_id as course_i2_4_0_,
        course1_.id as id1_0_1_,
        course1_.created_date as created_2_0_1_,
        course1_.last_updated_date as last_upd3_0_1_,
        course1_.name as name4_0_1_ 
    from
        student_course courses0_ 
    inner join
        course course1_ 
            on courses0_.course_id=course1_.id 
    where
        courses0_.student_id=?
		 */
	}
	
	
	public void insertStudentAndCourse(Student student, Course course){
		//Student student = new Student("Jack");
		//Course course = new Course("Microservices in 100 Steps");
		student.addCourse(course);
		course.addStudent(student);

		em.persist(student);
		em.persist(course);
	}

}
