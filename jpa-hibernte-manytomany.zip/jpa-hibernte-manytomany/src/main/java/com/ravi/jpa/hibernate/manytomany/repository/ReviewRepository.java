package com.ravi.jpa.hibernate.manytomany.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ravi.jpa.hibernate.manytomany.entity.Course;
import com.ravi.jpa.hibernate.manytomany.entity.Review;




@Repository
@Transactional
public class ReviewRepository {

	Logger logger= LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	EntityManager em;
	
	

	public Review findById(long id) {
		return em.find(Review.class, id);
	}
	
	public void deleteByid(long id) {
		Review review=em.find(Review.class, id);
		em.remove(review);
	}
	
	public void findAll() {
		TypedQuery<Review> query = em.createNamedQuery("get_all_review", Review.class);

		List<Review> resultList = query.getResultList();

		logger.info("Select  r  From Review r -> {}", resultList);
	}

	
	public void retreiveCourseForReviews(long reviewId) {
		
		Review review= em.find(Review.class,reviewId );
		
		
		Course course=review.getCourse();
		
		logger.info("{}",course);
	}
}
