package com.ravi.jpa.hibernate.manytomany.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

@Entity
public class Student {

	@Id
	@GeneratedValue
	private Long id;

	@Column(nullable = false)
	private String name;
	
	@OneToOne(fetch=FetchType.LAZY)
	private Passport passport;
	
	@ManyToMany
	@JoinTable(name="Student_Course",
	joinColumns=@JoinColumn(name="STUDENT_ID"),
	inverseJoinColumns=@JoinColumn(name="COURSE_ID"))
	private List<Course> courses= new ArrayList<>();
	/*
	 * Using JoinTable, we are explicitly telling to create Student_Course named join table(if not used, by default name will be Student_Courses)
	 * JoinColumn will say what will be the name of join column(if not used by default name will be Students_Id)
	 * InverseColumn purpose is to give name  to inverse column(if not used, name will be Courses_Id by default)
	 * 
	 * Note:See H2 Console
	 * 
	 * By cdefault, many to many relationship maintain lazy fetch
	 */

	protected Student() {
	}

	public Student(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Passport getPassport() {
		return passport;
	}

	public void setPassport(Passport passport) {
		this.passport = passport;
	}

	public Long getId() {
		return id;
	}
	
	

	public List<Course> getCourses() {
		return courses;
	}

	public void addCourse(Course course) {
		this.courses.add(course);
	}

	@Override
	public String toString() {
		return String.format("Student[%s]", name);
	}
}