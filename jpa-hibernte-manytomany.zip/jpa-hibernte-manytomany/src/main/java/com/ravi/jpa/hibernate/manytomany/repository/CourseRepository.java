package com.ravi.jpa.hibernate.manytomany.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ravi.jpa.hibernate.manytomany.entity.Course;
import com.ravi.jpa.hibernate.manytomany.entity.Review;





@Repository
@Transactional
public class CourseRepository {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	EntityManager em;


	public Course findById(Long id) {
		return em.find(Course.class, id);
	}

	public Course save(Course course) {

		if (course.getId() == null) {
			em.persist(course);
		} else {
			em.merge(course);
		}

		return course;
	}

	public void deleteById(Long id) {
		Course course = findById(id);
		em.remove(course);
	}

	public void playWithEntityManager() {
		Course course1 = new Course("Web Services in 100 Steps");
		em.persist(course1);
		
		Course course2 = findById(10001L);
		
		course2.setName("JPA in 50 Steps - Updated");
		
	}

	
	public void addReviewsForCourse(Long courseId,List<Review> reviews) {

		Course course = findById(courseId);
		logger.info("course.getReviews() -> {}", course.getReviews());
		
		for(Review review: reviews) {
		
		//setting the relationship
		course.addReview(review);
		review.setCourse(course); 
				
		//save it to the database
		em.persist(review);

		}
	}
	
	public void retreiveReviewsForCourse(long courseId) {
		
		Course course= findById(courseId);	
		List<Review> reviews=course.getReviews();
		logger.info("{}",reviews);
		
	}
	
	public  void reteiveCoursendStudent(long courseId) {
		Course course= findById(courseId);	
		/*
		 *     select
        course0_.id as id1_0_0_,
        course0_.created_date as created_2_0_0_,
        course0_.last_updated_date as last_upd3_0_0_,
        course0_.name as name4_0_0_ 
    from
        course course0_ 
    where
        course0_.id=?
		 */
		logger.info("Course: "+course);
		logger.info("Student :"+course.getStudents());
		/*
		 * select
        students0_.course_id as course_i2_4_0_,
        students0_.student_id as student_1_4_0_,
        student1_.id as id1_3_1_,
        student1_.name as name2_3_1_,
        student1_.passport_id as passport3_3_1_ 
    from
        student_course students0_ 
    inner join
        student student1_ 
            on students0_.student_id=student1_.id 
    where
        students0_.course_id=?
		 */
	}
	
}
