package com.ravi.semaphore;

public class Shared {
	static int count=0;

}
