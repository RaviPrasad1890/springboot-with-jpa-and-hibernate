package com.ravi.Generics;

public class TestMain {

	public static void main(String[] args) {
		
		Test<Integer,String> iObj= new Test<Integer,String>(15);
		System.out.println(iObj.gettTypeObject());
		
		
		Test<String,Integer> sObj= new Test<String,Integer>("Ravi");
		System.out.println(sObj.gettTypeObject());
		
		Test<String,Integer> siObj= new Test<String,Integer>("xyx",13);
		System.out.println(siObj.gettTypeObject()+"----"+siObj.getuTypeObject());
		
	}

}
