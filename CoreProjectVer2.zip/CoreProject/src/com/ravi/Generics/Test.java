package com.ravi.Generics;

public class Test<T,U> {//Test<T> {

	//An object of type T is declared
	T tTypeObject;
	
	U uTypeObject;
	

	public Test(T tTypeObject) {
		this.tTypeObject = tTypeObject;
	}


	public Test(T tTypeObject, U uTypeObject) {
		this.tTypeObject = tTypeObject;
		this.uTypeObject = uTypeObject;
	}


	public T gettTypeObject() {
		return this.tTypeObject;
	}

	public U getuTypeObject() {
		return this.uTypeObject;
	}
	
	
	
}
