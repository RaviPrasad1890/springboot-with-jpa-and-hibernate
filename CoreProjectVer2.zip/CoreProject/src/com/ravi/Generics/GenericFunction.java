package com.ravi.Generics;

public class GenericFunction {
	
	static <T,U> void genFun(T obj1,U obj2) {//A generic function which accepts two parameters
		
		System.out.println(obj1.getClass().getName() + 
                " = " + obj1); 
		
		System.out.println(obj2.getClass().getName() + 
                " = " + obj2); 
	}

	public static void main(String[] args) {
		

		genFun(11,"Ravi");
		System.out.println("---------------------------------");
		genFun('a',20f);

	}

}
