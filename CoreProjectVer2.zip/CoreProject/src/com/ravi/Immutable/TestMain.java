package com.ravi.Immutable;

public class TestMain {
	
	public static void main(String args[]) {
		Test t= new Test(10);
		System.out.println(t);
		
		t.modify(20);
		System.out.println(t);
		
		Test newTest= t.modify(30);
		System.out.println(newTest);
		
	}
/*
 * Once we create an object, we can't perform changes in that object.
 * If we are trying to perform, any change and iff there is a change in the content, than with those changes a new object
 * will be created.
 * If there is no change in the content then existing object will be reused.
 * This behaviour is nothing but immutability.
 * 
 */
}
