package com.ravi.DesignPatterns.CreationalDesignPattern.AbstractFactoryPattern;


public interface ComputerAbstractFactory {

	public Computer getComputer();
}

